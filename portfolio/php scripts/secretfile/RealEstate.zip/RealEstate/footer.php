<div class="bottompart">
		<div class="aboutus">
			 <?php dynamic_sidebar(8);  ?>
		</div>
		<div class="mortgagecenter">
			 <?php dynamic_sidebar(9);  ?>
		</div>
		<div class="bottom_right_col">
			 <?php dynamic_sidebar(10);  ?>
		</div>
	</div> <!-- bottom part #end -->
    
    
    
    <div class="footer">
		<div class="copyrights">
			
             <?php if ( get_option('ptthemes_footerpages') <> "" ) { ?>
			<ul>
			<?php wp_list_pages('title_li=&depth=0&include=' . get_option('ptthemes_footerpages') . '&sort_column=menu_order'); ?>
			</ul>
		<?php } ?>	
        
        <p> &copy; <?php the_time('Y'); ?> <?php bloginfo(); ?>  All right reserved.</p>

			
		</div>
		<div class="footerright">
			        
        <p class="author"> <span class="designby">Realestate Theme by </span>  <span class="templatic"> <a href="http://templatic.com" title="templatic.com"><strong>Premium Wordpress Themes</strong></a>  </span></p>				
		</div>
	</div><!--footer end-->
    </div> <!-- wrapper #end-->
    <script type="text/javascript">
function addToFavorite(property_id,action)
{
 	//alert(property_id);
	<?php 
	global $current_user;
	if($current_user->data->ID==''){ 
	?>
	window.location.href="<?php echo get_option('siteurl'); ?>/?page=login&page1=sign_in";
	<?php 
	}else{
	?>
	var fav_url; 
	if(action == 'add')
	{
		fav_url = '<?php echo get_option('siteurl'); ?>/index.php?page=favorite&action=add&pid='+property_id;
	}
	else
	{
		fav_url = '<?php echo get_option('siteurl'); ?>/index.php?page=favorite&action=remove&pid='+property_id;
	}
	$.ajax({	
		url: fav_url ,
		type: 'GET',
		dataType: 'html',
		timeout: 9000,
		error: function(){
			alert('Error loading agent favorite property.');
		},
		success: function(html){	
		<?php 
		if($_REQUEST['list']=='favourite')
		{ ?>
			document.getElementById('list_property_'+property_id).style.display='none';	
			<?php
		}
		?>	
			document.getElementById('favorite_property_'+property_id).innerHTML=html;								
		}
	});
	return false;
	<?php } ?>
}
</script>	
    <?php include (TEMPLATEPATH . "/library/includes/popup_frms.php");?>
 <?php wp_footer(); ?><?php if ( get_option('ptthemes_google_analytics') <> "" ) { echo stripslashes(get_option('ptthemes_google_analytics')); } ?>
</body>
</html>		