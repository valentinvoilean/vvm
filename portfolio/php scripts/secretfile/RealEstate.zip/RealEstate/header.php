<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head profile="http://gmpg.org/xfn/11">
<title>
<?php if ( is_home() ) { ?><?php bloginfo('description'); ?>&nbsp;|&nbsp;<?php bloginfo('name'); ?><?php } ?>
<?php if ( is_search() ) { ?>Search Results&nbsp;|&nbsp;<?php bloginfo('name'); ?><?php } ?>
<?php if ( is_author() ) { ?>Author Archives&nbsp;|&nbsp;<?php bloginfo('name'); ?><?php } ?>
<?php if ( is_single() ) { ?><?php wp_title(''); ?><?php } ?>
<?php if ( is_page() ) { ?><?php wp_title(''); ?><?php } ?>
<?php if ( is_category() ) { ?><?php single_cat_title(); ?>&nbsp;|&nbsp;<?php bloginfo('name'); ?><?php } ?>
<?php if ( is_month() ) { ?><?php the_time('F'); ?>&nbsp;|&nbsp;<?php bloginfo('name'); ?><?php } ?>
<?php if (function_exists('is_tag')) { if ( is_tag() ) { ?><?php bloginfo('name'); ?>&nbsp;|&nbsp;Tag Archive&nbsp;|&nbsp;<?php single_tag_title("", true); } } ?>
</title>

<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
<?php if (is_home()) { ?>
<?php if ( get_option('ptthemes_meta_description') <> "" ) { ?>
<meta name="description" content="<?php echo stripslashes(get_option('ptthemes_meta_description')); ?>" />
<?php } ?>
<?php if ( get_option('ptthemes_meta_keywords') <> "" ) { ?>
<meta name="keywords" content="<?php echo stripslashes(get_option('ptthemes_meta_keywords')); ?>" />
<?php } ?>
<?php if ( get_option('ptthemes_meta_author') <> "" ) { ?>
<meta name="author" content="<?php echo stripslashes(get_option('ptthemes_meta_author')); ?>" />
<?php } ?>
<?php } ?>
<link rel="stylesheet" type="text/css" href="<?php bloginfo('stylesheet_url'); ?>" media="screen" />

<?php if ( get_option('ptthemes_favicon') <> "" ) { ?>
<link rel="shortcut icon" type="image/png" href="<?php echo get_option('ptthemes_favicon'); ?>" />
<?php } ?>
<link rel="alternate" type="application/rss+xml" title="RSS 2.0" href="<?php if ( get_option('ptthemes_feedburner_url') <> "" ) { echo get_option('ptthemes_feedburner_url'); } else { echo get_bloginfo_rss('rss2_url'); } ?>" />
<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
<!--[if lt IE 7]>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/library/js/pngfix.js"></script>
<link type='text/css' href='<?php bloginfo('template_directory'); ?>/library/css/basic_ie.css' rel='stylesheet' media='screen' />

<SCRIPT src="<?php bloginfo('template_directory'); ?>/library/js/jquery.js" 
type=text/javascript></SCRIPT>

<SCRIPT src="<?php bloginfo('template_directory'); ?>/library/js/jquery.helper.js" 
type=text/javascript></SCRIPT>

<![endif]-->

<?php if ( get_option('ptthemes_scripts_header') <> "" ) { echo stripslashes(get_option('ptthemes_scripts_header')); } ?>
<link href="<?php bloginfo('template_directory'); ?>/library/css/superfish.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css"  href="<?php bloginfo('template_directory'); ?>/library/css/print.css" media="print">
<link type='text/css' href='<?php bloginfo('template_directory'); ?>/library/css/basic.css' rel='stylesheet' media='screen' />
<link type='text/css' href='<?php bloginfo('template_directory'); ?>/library/css/dropdownmenu.css' rel='stylesheet' media='screen' />
<?php if (!is_home() || $_REQUEST['page']!='' ) { ?>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/library/js/jquery-1.2.6.min.js" ></script>
<?php }?>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/library/js/blogger.js"></script>

<?php if ( is_single() || is_page() ) wp_enqueue_script( 'comment-reply' ); ?>
<?php if(is_home() && $_REQUEST['page']=='property_submit'){ get_location_map_javascripts();}?>
<?php
	if ( is_singular() && get_option( 'thread_comments' ) )
		wp_enqueue_script( 'comment-reply' );
?>
<?php wp_head(); ?>
<?php if ( get_option('ptthemes_customcss') ) { ?>
<link href="<?php bloginfo('template_directory'); ?>/custom.css" rel="stylesheet" type="text/css">
<?php } ?>
</head>

<body <?php body_class(); ?>>
<div id="wrapper">
	<div class="header">
		
        
        <?php if ( get_option('ptthemes_show_blog_title') ) { ?>
                
	                   <div class="logo">  <div class="blog-title"><a href="<?php echo get_option('home'); ?>/"><?php bloginfo('name'); ?></a> </div>
                        <p class="blog-description">
                          <?php bloginfo('description'); ?>
                        </p> </div>
                
                <?php } else { ?>
                 
                  <div class="logo"><a href="<?php echo get_option('siteurl');?>"><img src="<?php if ( get_option('ptthemes_logo_url') <> "" ) { echo get_option('ptthemes_logo_url'); } else { echo get_bloginfo('template_directory').'/images/i-logo.png'; } ?>" alt="<?php bloginfo('name'); ?>" alt="" title="" /></a>
        		<p><?php bloginfo('description'); ?></p></div>
                 <?php } ?>
        
         
       <div class="toplinks">
 			<ul >
			<?php
			if(is_allow_user_register())
			{
				global $current_user;
				if($current_user->ID)
				{
				?>
					<li class="welcome"><?php _e(WELCOME_TEXT);?>, <strong><?php echo $current_user->display_name;?></strong></li>
					<li><a href="<?php echo get_author_link($echo = false, $current_user->data->ID);?>" class="signin"><?php _e(MY_PROFILE_TEXT);?></a></li>
					<li><a href="<?php echo get_option('siteurl');?>/?page=login&action=logout" class="signin"><?php _e(LOGOUT_TEXT);?></a></li>
				<?php
				}else
				{
				?>
					<li><?php _e(WELCOME_TEXT);?>, <strong><?php _e(GUEST_TEXT);?></strong></li>
					<li><a href="<?php echo get_option('siteurl');?>/?page=login&page1=sign_in" class="signin"><?php _e(SIGN_IN_TEXT);?></a></li>
					<li><a href="<?php echo get_option('siteurl');?>/?page=login&page1=sign_up" class="signup"><?php _e(SIGN_UP_TEXT);?></a></li>			
				<?php
				}
			}
			?>
			</ul>
            
            
            
            <div class="header_advt">
                       
                       <?php if ( get_option('ptthemes_header_advt') != "") { ?>
                           <?php echo stripslashes(get_option('ptthemes_header_advt'));  ?>
                         <?php } ?>  
                        
						<?php
						if(is_user_can_add_property())
						{
						global $current_user;
						?>
						  <div class="submitpropertybtn"><a href="<?php echo get_option('siteurl');?>/?page=property_submit"><?php _e(SUBMIT_PROPERTY_TEXT);?></a> </div>
					<?php }
					?>
					 
						 </div>
                   
		 
        </div>
		<div class="menu">
			 <?php if (function_exists('dynamic_sidebar') && dynamic_sidebar('Header Navigation') ){}else{  ?>	
             <?php
				global $wpdb;
				$blogcatname = get_option('ptthemes_blogcategory');
				$catid = $wpdb->get_var("SELECT term_ID FROM $wpdb->terms WHERE name = \"$blogcatname\"");
				 ?>
				<ul >
                		<li class="hometab <?php if ( is_home() && $_REQUEST['page']=='' ) { ?> current_page_item <?php } ?>"><a href="<?php echo get_option('home'); ?>/"><?php _e(HOME_TEXT); ?></a></li>
						<?php if(get_option('ptthemes_borwse_link_flag') && !get_option('ptthemes_borwse_link_pos_flag')){?>
						<li class="<?php if($_REQUEST['s']=='viewmore'){ echo 'current_page_item';}?>">
							<a href="<?php echo get_option('siteurl');  ?>/index.php?s=viewmore"><?php _e(BROWSE_PROPERTY_TEXT);?></a>
						</li>
						<?php }?> 
						<?php if(get_option('ptthemes_agents_link_flag') && !get_option('ptthemes_agents_link_post_flag')){?>
					   <li class="<?php if($_REQUEST['page']=='agents'){ echo 'current_page_item';}?>">
							<a href="<?php echo get_option('siteurl');  ?>/?page=agents"><?php _e(AGENT_LISTING_TEXT);?></a>
						</li>
						<?php }?>
					  <?php wp_list_pages('title_li=&depth=0&exclude=' . get_inc_pages("pag_exclude_") .'&sort_column=menu_order'); ?>
					 <?php if ( get_option('ptthemes_blogcategory') <> "" ) { ?>
					 <?php /*?><li <?php if ( is_category() || is_tag() ) { ?> class="current_page_item" <?php } ?>><a href="<?php echo get_category_link( $catid ); ?>" title="<?php echo $blogcatname; ?>"><?php echo $blogcatname; ?></a></li>               <?php */?>      
					 <?php
					 if($catid)
					 {
						 $catid = get_sub_categories($catid,'string');
						 wp_list_categories ('title_li=&depth=0&include=' . $catid . '&sort_column=menu_order'); 
					}
					 ?>
					
					<?php } ?>
					 
					
					<?php if(get_option('ptthemes_borwse_link_flag') && get_option('ptthemes_borwse_link_pos_flag')){?>
						<li class="<?php if($_REQUEST['s']=='viewmore'){ echo 'current_page_item';}?>">
							<a href="<?php echo get_option('siteurl');  ?>/index.php?s=viewmore"><?php _e(BROWSE_PROPERTY_TEXT);?></a>
						</li>
						<?php }?> 
						<?php if(get_option('ptthemes_agents_link_flag') && get_option('ptthemes_agents_link_post_flag')){?>
					   <li class="<?php if($_REQUEST['page']=='agents'){ echo 'current_page_item';}?>">
							<a href="<?php echo get_option('siteurl');  ?>/?page=agents"><?php _e(AGENT_LISTING_TEXT);?></a>
						</li>
						<?php }?>
				</ul>
                <?php }?>
		</div>
	</div><!-- #header end -->
	<?php $totalpost_count = 0;?>