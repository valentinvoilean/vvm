<?php get_header(); ?>


<div class="breadcrumbs">
		<p><?php if ( get_option( 'ptthemes_breadcrumbs' )) { yoast_breadcrumb('',''); } ?></p>
		<span class="findproperties" onclick="show_hide_propertysearchoptions();"><a href="javascript:void(0);"><?php _e(FIND_PROPERTIES_TEXT);?></a></span>
	</div>
    <?php require_once (TEMPLATEPATH . '/library/includes/search.php');  ?>
	<!-- search end -->

	<?php
	global $wp_query, $post;
	$current_term = $wp_query->get_queried_object();
	$blog_cat = get_blog_sub_cats_str($type='array');
		
	if(is_category())
	{
		if(in_array($current_term->term_id,$blog_cat))
		{
			require_once (TEMPLATEPATH . '/library/includes/blog_listing.php');	
		}else
		{
			require_once (TEMPLATEPATH . '/library/includes/property_listing.php');
		}
	}
	else
	{
		require_once (TEMPLATEPATH . '/library/includes/blog_listing.php');
	}
	?>
<?php get_footer(); ?>