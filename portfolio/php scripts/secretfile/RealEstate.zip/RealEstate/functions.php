<?php 
/*************************************************************
* Do not modify unless you know what you're doing, SERIOUSLY!
*************************************************************/
error_reporting(E_ERROR);
//ini_set('session.gc_probability',1);

load_theme_textdomain('default');
/*load_textdomain( 'default', TEMPLATEPATH.'/en_US.mo' );*/

global $blog_id;
if(get_option('upload_path') && !strstr(get_option('upload_path'),'wp-content/uploads'))
{
	$upload_folder_path = "wp-content/blogs.dir/$blog_id/files/";
}else
{
	$upload_folder_path = "wp-content/uploads/";
}
global $blog_id;
if($blog_id){ $thumb_url = "&amp;bid=$blog_id";}

if ( function_exists( 'add_theme_support' ) ){
	add_theme_support( 'post-thumbnails' );
	}

if($_REQUEST['coupon_code'])
{
	add_filter('posts_join', 'product_filter_join');
	function product_filter_join($join) 
	{
		global $wpdb;
	
			$join .= " JOIN $wpdb->postmeta";
			$join .= " ON $wpdb->posts.ID = $wpdb->postmeta.post_id";
			$join .= " AND ($wpdb->postmeta.meta_key = 'coupon_code') and ($wpdb->postmeta.meta_value like '".$_REQUEST['coupon_code']."')";
			//$join .= " AND p.post_status='publish'";
		return $join;
	}
}

/* Admin framework version 2.0 by Zeljan Topic */

require_once (TEMPLATEPATH . '/library/map/map_functions.php');

// Theme variables
require_once (TEMPLATEPATH . '/library/functions/theme_variables.php');

//** ADMINISTRATION FILES **//

    // Theme admin functions
    require_once ($functions_path . 'admin_functions.php');

    // Theme admin options
    require_once ($functions_path . 'admin_options.php');

    // Theme admin Settings
    require_once ($functions_path . 'admin_settings.php');

   
//** FRONT-END FILES **//
	require_once ($functions_path . 'image_resizer.php');
	
    // Widgets
    require_once ($functions_path . 'widgets_functions.php');

    // Custom
    require_once ($functions_path . 'custom_functions.php');

    // Comments
    require_once ($functions_path . 'comments_functions.php');
	
   require_once ($functions_path . 'yoast-posts.php');	
	require_once ($functions_path . 'yoast-canonical.php');
	require_once ($functions_path . 'yoast-breadcrumbs.php');
	
	
	require_once ($functions_path . '/admin_dashboard.php');
	require_once (TEMPLATEPATH . '/language.php');
	
	require(TEMPLATEPATH . "/product_menu.php");
	
	require($functions_path . "/auto_install_setting.php");
	
	function get_image_cutting_edge($args=array())
{
	if($args['image_cut'])
	{
		$cut_post =$args['image_cut'];
	}else
	{
		$cut_post = get_option('ptthemes_image_x_cut');
	}
	if($cut_post)
	{		
		if($cut_post=='top')
		{
			$thumb_url .= "&amp;a=t";	
		}elseif($cut_post=='bottom')
		{
			$thumb_url .= "&amp;a=b";	
		}elseif($cut_post=='left')
		{
			$thumb_url .= "&amp;a=l";
		}elseif($cut_post=='right')
		{
			$thumb_url .= "&amp;a=r";
		}elseif($cut_post=='top right')
		{
			$thumb_url .= "&amp;a=tr";
		}elseif($cut_post=='top left')
		{
			$thumb_url .= "&amp;a=tl";
		}elseif($cut_post=='bottom right')
		{
			$thumb_url .= "&amp;a=br";
		}elseif($cut_post=='bottom left')
		{
			$thumb_url .= "&amp;a=bl";
		}
	}
	return $thumb_url;
}
?>