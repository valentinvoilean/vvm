<?php
///header.php///
define('WELCOME_TEXT',__('Welcome'));
define('HOME_TEXT',__('Home'));
define('SIGN_IN_TEXT',__('Sign In'));
define('SIGN_UP_TEXT',__('Sign Up'));
define('GUEST_TEXT',__('Guest'));
define('SUBMIT_PROPERTY_TEXT',__('List for Free'));
define('MY_PROFILE_TEXT',__('My Dashboard'));
define('LOGOUT_TEXT',__('Logout'));
define('BROWSE_PROPERTY_TEXT',__('Browse Properties'));
define('AGENT_LISTING_TEXT',__('Sellers'));

//search.php//
define('SEARCH_PROPERTY_TITLE',__('Search Property'));
define('SEARCH_PROPERTY_FOR_TEXT',__('Properties for'));
define('SEARCH_ALL_TEXT',__('All'));
define('SEARCH_BUY_TEXT',__('Buy'));
define('SEARCH_RENT_TEXT',__('Order Your Home'));
define('SEARCH_LOCATION_TEXT',__('Location'));
define('SEARCH_ALL_LOCATION_TEXT',__('All Locations'));
define('SEARCH_AREA_TEXT',__('Area'));
define('SEARCH_ALL_AREA_TEXT',__('All Area'));
define('SEARCH_PRICE_RANGE_TEXT',__('Price Range'));
define('SELECT_ALL_PRICE_TEXT',__('All Price Range'));
define('SEARCH_KEYWORD_TEXT',__('Keyword'));
define('SEARCH_BEDROOMS_TEXT',__('Bedrooms'));
define('SELECT_ALL_BEDROOMS_TEXT',__('All Bedrooms'));
define('SEARCH_BATHROOM_TEXT',__('Bathroom'));
define('SELECT_ALL_BATHROOM_TEXT',__('All Bathroom'));
define('SEARCH_PROPERTY_TEXT',__('Search Properties'));
define('SEARCH_BY_PROPERTY_ID_TEXT',__('Search by Property ID'));
define('SEARCH_PROPERTY_ID_TEXT',__('Property ID'));
define('SELECT_TEXT',__('Search'));
define('CITY_STATE_ZIP_SRCH_TEXT',__('City, State or Zip Code'));
define('PROPERTY_ID_VALUE_TEXT',__('#1223'));


//property_detail.php
define('SEND_TO_FRND_TEXT',__('Send to Friend'));
define('ADD_TO_FAVOURITE_TEXT',__('Add to Favorite'));
define('PRINT_TEXT',__('Print'));
define('SHARE_THIS_LISTING_TEXT',__('Share this:'));
define('BASIC_INFO_TEXT',__('Home Information'));
define('PRICE_TEXT',__('Price'));
define('ADDRESS_TEXT',__('Address'));
define('TYPE_TEXT',__('Type'));
define('CITY_TEXT',__('City'));
define('BEDS_TEXT',__('Bedrooms'));
define('STATE_TEXT',__('State'));
define('BATHS_TEXT',__('Bathrooms'));
define('COUNTRY_TEXT',__('County'));
define('SQ_FT_TEXT',__('Area'));
define('ZIP_CODE_TEXT',__('Zip Code'));
define('ADD_FEATURE_TEXT',__('Additional Features'));
define('PROPERYT_MAP_TEXT',__('Property Map'));
define('INQ_THIS_PROPERTY_TEXT',__('Inquiry this Property'));
define('HAVE_A_QUE_TEXT',__('Have A Question?'));
define('FIRST_NAME_TEXT',__('First Name'));
define('LAST_NAME_TEXT',__('Last Name'));
define('EMAIL_TEXT',__('Email'));
define('HOW_MAY_WE_HELP_TEXT',__('How May We Help You?'));
define('SUBMIT_BUTTON',__('Submit'));
define('IMAGE_LOADING_TEXT',__('Loading image. Please wait'));
define('FOR_TEXT',__('For'));
define('BY_AGENT_TEXT',__('by Seller'));
define('LISTING_DETAIL_TEXT',__('Listing Details'));
define('LISTING_ON_TEXT',__('Listed on'));
define('PROPERTY_ID_TEXT',__('Property Id'));
define('AGENT_CONTACT_INFO_TEXT',__('Seller Contact  Info'));
define('AGENT_WEBSITE_TEXT',__('Visit Seller\'s Website'));
define('AGENT_OTHR_LISTING_TEXT',__('Seller\'s Other Listings'));
define('PHONE_TEXT',__('Phone'));
define('SCHEDULE_SHOW_TEXT',__('Schedule a Showing'));
define('NAME_TEXT',__('Name'));
define('EMAIL_TEXT',__('Email address'));
define('PHONE_NUMBER_TEXT',__('Phone Number'));
define('MESSAGE_TEXT',__('Message'));
define('SEND_BTN_TEXT',__('Send'));
//define('INQUIRY_MSG',__('Inquiry Send Successfully!'));




//blog_listing.php
define('CATEGORY_TEXT',__('Category'));

//property_listing.php
define('SWITCH_THUMB_TEXT',__('Switch Thumb'));
define('NO_PROPERTY_AVAILABLE_MSG',__('Sorry! no property available matching your criteria. Kindly try a different search'));
define('BEDS_TEXT',__('Bed(s)'));
define('BATHS_TEXT',__('Bath(s)'));
define('VIEW_MORE_DETAILS_TEXT',__('View More Details'));
define('EMAIL_TO_AGENT_TEXT',__('Email to Seller'));
define('SEARCH_TEXT',__('Search'));
define('SEARCH_TITLE',__('Search Results'));
define('SEARCH_ALL_PROPERTY_TITLE',__('All Properties'));



//featured.php
define('FEATURED_PROPERTIES_TEXT',__('Featured Properties'));

//related_properties.php
define('SIMILAR_PROPERTIES_TEXT',__('Similar Properties'));


//latest_lisgint_home.php
define('LATEST_PROPERTIES_TEXT',__('Latest Properties'));
define('VIEW_MORE_PROPERTIES_TEXT',__('View More Properties'));

//registration.php
define('FORGOT_PW_TEXT',__('Forgot Password?'));
define('USERNAME_EMAIL_TEXT',__('E-mail'));
define('USERNAME_TEXT',__('Username'));
define('PASSWORD_TEXT',__('Password'));
define('REMEMBER_ON_COMPUTER_TEXT',__('Remember me on this computer'));
define('GET_NEW_PW_TEXT',__('Get New Password'));
define('INDICATES_MANDATORY_FIELDS_TEXT',__('Indicates mandatory fields'));
define('REGISTRATION_NOW_TEXT',__('Sign Up Now'));
define('PERSONAL_INFO_TEXT',__('Personal Information'));
define('EMAIL_TEXT',__('E-mail'));
define('FIRST_NAME_TEXT',__('First Name'));
define('LAST_NAME_TEXT',__('Last Name'));
define('ADD_INFO_TEXT',__('Address Information'));
define('ADDRESS1_TEXT',__('Address1'));
define('ADDRESS2_TEXT',__('Address2'));
define('CITY_TEXT',__('City'));
define('STATE_TEXT',__('State'));
define('COUNTRY_TEXT',__('Country'));
define('POSTAL_CODE_TEXT',__('Postal Code'));
define('REGISTRATION_MESSAGE',__('(Note: A password will be E-mailed to you for future usage.)'));
define('YR_WEBSITE_TEXT',__('Your Website'));
define('YR_TWITTER_TEXT',__('Your Twitter URL'));

define('PHONE_NUMBER_TEXT',__('Phone Number'));
define('REGISTER_NOW_TEXT',__('Register Now'));
define('SIGN_IN_BUTTON',__('Sign In'));
define('REGISTER_BUTTON',__('Register'));
define('SIGN_IN_BUTTON',__('Sign In'));
define('SIGN_IN_PAGE_TITLE',__('Sign In'));
define('INVALID_USER_PW_MSG',__('Invalid Username/Password.'));
define('REG_COMPLETE_MSG',__('Registration complete. Please check your e-mail for login details.'));
define('NEW_PW_EMAIL_MSG',__('We just sent you a new password. Kindly check your E-mail now.'));
define('EMAIL_CONFIRM_LINK_MSG',__('A confirmation link has been sent to you via email. Kindly check your E-mail now.'));
define('USER_REG_NOT_ALLOW_MSG',__('User registration has been disabled by the admin.'));
define('YOU_ARE_LOGED_OUT_MSG',__('You are now logged out.'));
define('ENTER_USER_EMAIL_NEW_PW_MSG',__('Please enter your E-mail address as username. You will receive a new password via E-mail.'));
define('OTHER_INFO_TEXT',__('Other Information'));
define('TWITTER_TEXT',__('Twitter URL'));
define('YR_DESCRIPTION_TEXT',__('Description'));
define('YR_PICTURE_TEXT',__('Profile picture'));
define('INVALID_USER_FPW_MSG',__('Invalid Email, Please check'));
define('PW_SEND_CONFIRM_MSG',__('Check your e-mail for your new password.'));

//edit_profile.php
define('EDIT_PROFILE_PAGE_TITLE',__('Edit Profile'));
define('PW_CHANGE_SUCCESS_MSG',__('Password Changed successfully.'));
define('INFO_UPDATED_SUCCESS_MSG',__('Your information is updated successfully.'));
define('CHANGE_PW_TEXT',__('Change Password'));
define('NEW_PW_TEXT',__('New Password'));
define('CONFIRM_NEW_PW_TEXT',__('Confirm New Password'));
define('EDIT_PROFILE_UPDATE_BUTTON',__('Update'));
define('PW_CHANGE_SUCCESS_MSG',__('Password changed successfully.'));

//dashboard.php
define('DASHBOARD_TEXT',__('Dashboard'));
define('EDIT_PROPERTY_TEXT',__('Edit Property'));
define('RENEW_PROPERTY_TEXT',__('Renew Property'));
define('DELETE_PROPERTY_TEXT',__('Delete Property'));
define('PROPERTY_UPDATE_SUCCESS_MSG',__('Property information updated successfully'));
define('PROPERTY_DELETE_SUCCESS_MSG',__('Property information deleted successfully'));

//sidebar.php
define('MY_ACCOUNT_TEXT',__('My Account'));
define('DASHBOARD_TEXT',__('Dashboard'));

//send_inquiry_form.php
define('SEND_INQUIRY_TEXT',__('Send Inquiry'));
define('YOUR_NAME_TEXT',__('Your Name'));
define('EMAIL_ADDRESS_TEXT',__('Email Address'));
define('SUBJECT_TEXT',__('Subject'));
define('COMMENTS_TEXT',__('Message'));
define('EMAIL_FRND_CONTENT_DEFAULT',__('Hi there, Kindly do check this property that I think you might be interested in..'));
define('AGENT_CONTENT_DEFAULT',__('Hi there, I would like to inquire about this property. I would like to ask more info about...'));
define('INVALID_EMAIL_ID_JS_MSG',__('Invalid E-mail ID'));
define('SEND_TO_FRND_TEXT',__('Send to Friend'));

//email_friend_frm.php
define('EMAIL_POST_TEXT',__('Email This Post'));
define('EMAIL_FRND_TEXT',__('Email This Post'));
define('FRND_NAME_TEXT', __('To Name'));
define('FRND_EMAIL_TEXT', __('To Email'));
define('YOUR_EMAIL_TEXT',__('Your Email'));

//property_frm.php
define('ADD_PROPERTY_TEXT',__('Submit Property'));
define('PROPERTY_INFO_TEXT',__('Property Information'));
define('PRO_NAME_TEXT',__('Property Name'));

define('PRO_LOCATION_TEXT',__('Location'));
define('PRO_ADDRESS_TEXT',__('Address'));
define('PRO_CITY_TEXT',__('City'));
define('PRO_STATE_TEXT',__('State'));
define('PRO_COUNTRY_TEXT',__('Country'));
define('PRO_ZIP_TEXT',__('Zip Code'));
define('PRO_BATHROOM_TEXT',__('Bathroom'));
define('PRO_BEDROOM_TEXT',__('Bedroom'));
define('PRO_PRICE_TEXT',__('Price'));
define('PRO_PRICE_RANGE_TEXT',__('Price Range'));
define('PRO_SQFT_TEXT',__('Sq. Ft'));
//define('COLOR_TEXT',__('Color'));
define('PRO_TYPE_TEXT',__('Type'));
define('PRO_SQFT_TEXT',__('Sq. Ft'));
define('PRO_DESCRIPTION_TEXT',__('Description'));
define('PRO_ADD_FEATURES_TEXT',__('Additional Features'));
define('PRO_PREVIEW_BUTTON',__('Review Your Listing'));
define('PRO_CANCEL_BUTTON',__('Cancel'));
define('PRO_BACK_AND_EDIT_TEXT',__('Go Back and Edit'));
define('PRO_ADD_BUTTON',__('Add'));
define('PRO_EDIT_BUTTON',__('Update'));

//property_preview.php
define('PRO_SUBMIT_BUTTON',__('Pay & Publish'));
define('PRO_UPDATE_BUTTON',__('Update Now'));
define('PRO_DELETE_PRE_MSG',__('Are you really sure want to DELETE this property? Deleted property can not be recovered later'));
define('PRO_DELETE_BUTTON',__('Yes, Delete Please!'));
define('SELECT_PAY_MEHTOD_TEXT',__('Select Payment Method'));

//success.php
define('PROPERTY_POSTED_SUCCESS_TITLE',__('Property submitted successfully.'));
define('PROPERTY_RENEW_SUCCESS_TITLE',__('Property listing has been renewed successfully'));
define('PROPERTY_POSTED_SUCCESS_MSG',__('<p class="sucess_msg">Thank you, your property request has been received successfully.</p><p><a href="[#$submited_property_link#]"  class="btn_input_highlight" >View your submitted Property &raquo;</a></p> <p>&nbsp; </p><p>Thanks for listing your property at [#$store_name#].</p>'));
define('PROPERTY_POSTED_SUCCESS_PREBANK_MSG',__('<p>Thanks. The property has been submitted successfully.</p><p>In order to publish the property, kindly transfer amount of <u>[#$order_amt#] </u> in our bank. Our bank account details are mentioned below.</p>
<p>Bank Name : [#$bank_name#]</p><p>Account Number : [#$account_number#]</p><br><p>Please include the following reference : [#$orderId#]</p><p><a href="[#$submited_property_link#]" >View your submitted Property &raquo;</a></p><br><p>Thanks for listing your property at [#$store_name#].</p>'));

//return.php
define('PAYMENT_SUCCESS_TITLE',__('Payment Success'));
define('PAYMENT_SUCCESS_MSG1',__('Thanks for listing your property at our site'));
define('PAYMENT_SUCCESS_MSG2',__('Your payment has been successfully received and your property is published.<br>'));
define('PAYMENT_SUCCESS_MSG3',__('Thank you for become our valued member'));
define('PAYMENT_SUCCESS_AND_RETURN_MSG',__('<h4>your payment has been received successfully and the property you submitted has been published on our site.</h4><p><a href="[#$submited_property_link#]" >View your submitted Property &raquo;</a></p><h5>Thank you for become our member at [#$store_name#].</h5>'));

//cancel.php
define('PAY_CANCELATION_TITLE',__('Payment Cancellation'));
define('PAY_CANCEL_MSG',__('Paypal payment has been cancelled successfully. The property submitted by you has not been published.'));
define('PRPOERTY_PAY_CANCEL_MSG',__('<p><a href="[#$submited_property_link#]" >View your submitted Property &raquo;</a></p>'));

//property_frm_with_reg.php
define('SELECT_PRICE_TEXT',__('-- Select Price --'));
define('SELECT_BEDROOMS_TEXT',__('-- Select Bedroom --'));
define('SELECT_LOCATION_TEXT',__('-- Select Location --'));

define('EVENT_ADDRESS_LAT',__('Address Latitude'));
define('EVENT_ADDRESS_LNG',__('Address Longitude'));
define('GET_LATITUDE_MSG',__('Please enter latitude for google map perfection. eg. : <b>39.955823048131286</b>'));
define('GET_LOGNGITUDE_MSG',__('Please enter logngitude for google map perfection. eg. : <b>-75.14408111572266</b>'));
define('SUBMIT_PROPERTY_TEXT',__('Submit Property'));
define('IAM_TEXT',__("I'm a"));
define('EXISTING_USER_TEXT',__("Existing User"));
define('NEW_USER_TEXT',__("New User? Register Now"));
define('LOGIN_TEXT',__('Login'));
define('PASSWORD_TEXT',__('Password'));
define('PROPERTY_TITLE_TEXT',__('Property  Title'));
define('FOR_SALE_RENT_TEXT',__('For Sale/Order it?'));
define('BEDROOMS_TEXT',__('Bedrooms'));
define('SELECT_BATHROOMS_TEXT',__('-- Select Bathrooms --'));
define('BATHROOMS_TEXT',__('Bathrooms'));
define('AREA_TEXT',__('Area'));
define('MLS_NO_TEXT',__('MLS No.'));
define('PRO_PHOTO_TEXT',__('Property Photo'));
define('PHOTOES_BUTTON',__('Photos'));
define('GENERAL_PROPERTY_INFO_TEXT',__('General Property information'));
define('LIST_TYPE_TEXT',__('List Type'));
define('PASSWORD_TEXT',__('Password'));
define('SALE_TEXT',__('Sale'));
define('RENT_TEXT',__('Order it'));
define('IS_A_FEATURE_PRO_TEXT',__('This property is listed as Featured. Do you want to remove it from feature listing?'));
define('CONTACT_DETAIL_TITLE',__('Contact Details'));
define('CONTACT_NAME_TEXT',__('Contact name'));
define('CITY_TEXT',__('City'));
define('STATE_TEXT',__('State'));
define('MOBILE_TEXT',__('Mobile Number'));
define('EMAIL_TEXT',__('Email'));
define('WEBSITE_TEXT',__('Website'));
define('TWITTER_TEXT',__('Twitter'));
define('PHOTO_TEXT',__('Upload Photo'));
define('BIODATA_TEXT',__('Short Biodata Information'));
define('IMAGE_TYPE_MSG',__('Note : PNG, GIF of JPEG only, for better image quality upload image size 150x150'));
define('HTML_TAGS_ALLOW_MSG',__('Note : Basic HTML tags are allowed'));
define('PRO_ADD_COUPON_TEXT',__('Coupon Code'));
//general
define('FIND_PROPERTIES_TEXT',__('Find Properties'));

//popup E-mail Agent
define('POP_TITLE_TEXT',__('Email Seller'));
define('AGT_NAME_TEXT',__('Name'));
define('AGT_EMAIL_TEXT',__('E-mail'));
define('AGT_PHONE_TEXT',__('Phone'));
define('AGT_MESSAGE_TEXT',__('Message'));
define('AGT_SUBMIT_BTN',__('Send Now'));
define('AGT_SUCCESS_MSG',__('<p class="sucess_msg">Message Sent Successfully!</p>'));

//author.php
define('PROFILE_EDIT_TEXT',__('Edit Profile'));
define('PRO_WEBSITE_TEXT',__('Visit Website'));
define('PRO_TWITTER_TEXT',__('Twitter'));
define('PRO_PROPERTY_LIST_TEXT',__('Properties Listed'));
define('PRO_PHONE_TEXT',__('Phone'));
define('PRO_EMAIL_AGENT_TEXT',__('Email This Seller'));
define('PRO_LISTED_PROPERTY_TEXT',__('My Listed Properties'));
define('PRO_FAVORITE_PROPERTY_TEXT',__('My Favorite Properties'));
define('PRO_FOR_TEXT',__('For'));
define('PRO_AREA_TEXT',__('Area'));
define('PRO_MLS_TEXT',__('MLS #'));  
define('PRO_PROPERTY_ID_TEXT',__('Property ID'));  
define('PRO_POSTED_ON_TEXT',__('Posted on'));  
define('PRO_AGENT_NAME_TEXT',__('Seller Name'));  
define('PRO_EDIT_TEXT',__('Edit'));  
define('PRO_DELETE_TEXT',__('Delete')); 
define('PRO_EXPERIANCE_TEXT',__('expires in')); 
define('PRO_DAYS_TEXT',__('days'));  
define('PRO_RENEW_TEXT',__('Renew'));  
define('PRO_NO_PROPERTY_MSG',__('No property available.'));  
define('AGENT_TITLE',__('Seller'));
define('PROPERTIES_BY_THIS_AGENT_TEXT',__('Properties listed by this Seller'));

//agents.php
define('AGT_LISTING_TEXT',__('Sellers'));
define('AGT_SORTBY_TEXT',__('Sort by'));
define('AGT_ALL_LISTING_TEXT',__('All Sellers'));
define('AGT_ALPHA_LISTING_TEXT',__('Alphabetical'));
define('AGT_MOST_LISTING_TEXT',__('Most Properties'));
define('AGT_LISTED_TEXT',__('Listed'));
define('AGT_PROPERTY_TEXT',__('Properties'));
define('AGT_VISIT_WEBSITE_TEXT',__('Visit Seller\'s Website'));
define('AGT_TWITTER_TEXT',__('Twitter'));
define('AGT_EMAIL_TEXT',__('Email Seller'));
define('AGT_PHONE_TEXT',__('Phone'));
define('AGT_VIEW_PROFILE_TEXT',__('View Profile'));
define('AGT_NO_LISTING_MSG',__('No listing available begining with '));

//property_preview_buttons.php
define('GOING_TO_PAY_MSG',__('You are going to pay'));
define('NO_PAYMENT_METHOD_MSG',__('None of payment method is active right now.'));
define('GOING_TO_UPDATE_MSG',__('You are going to update'));
define('EMAIL_USERNAME_EXIST_MSG',__('Email ID already exists. Please select a different Email.'));
define('WRONG_COUPON_MSG',__('Invalid Coupon Code'));
//image_uploader.php
define('IMAGE_ORDERING_MSG',__('Note : You will be able to sort image order once the property is submitted'));

//page_contact.php
define('CONTACT_PAGE_SUCCESS_MSG',__('Thank you. Your email sent successfully'));
define('EMAIL_CONTACT_TEXT',__('Email address'));
define('NAME_CONTACT_TEXT',__('Your Name'));
define('SUBJECT_CONTACT_TEXT',__('Subject'));
define('MESSAGE_CONTACT_TEXT',__('Message'));
define('SEND_CONTACT_BUTTON',__('Send'));

//payment pages
define('AUTHORISE_NET_MSG',__('Processing for Authorize.net, Please wait ....'));
define('TWOCO_MSG',__('Processing for 2CO, Please wait ....'));
define('GOOGLE_CHKOUT_MSG',__('Processing for Google Checkout, Please wait ....'));
define('PAYPAL_MSG',__('Processing for Paypal, Please wait ....'));
define('WORLD_PAY_MSG',__('Processing for Worldpay, Please wait ....'));

//DEFAULT EMAIL FORMATS
define('SEND_INQUIRY_EMAIL_DEFAULT_TEXT',__('[SUBJECT-STR]Property Inquiry[SUBJECT-END]<p>Dear [#$to_name#],</p><p>Here is an Inquiry for you related to <b>[#$post_title#]</b></p><p><b>Message : </b></p><p>[#$frnd_comments#]</p><p>Thank you, [#$your_name#]</p>'));
define('EMAIL_FRIEND_EMAIL_DEFAULT_TEXT',__('[SUBJECT-STR]Email the post [SUBJECT-END]<p>Dear [#$to_name#],</p><p>your friend send message for <b>[#$post_title#]</b> </p><p><b>Subject : [#$frnd_subject#]</b></p><p>[#$frnd_comments#]</p><p>Thank you, [#$your_name#]</p>'));
define('REGISTRATION_EMAIL_DEFAULT_TEXT',__('[SUBJECT-STR]Registration Email[SUBJECT-END]<p>Dear [#$user_name#],</p><p>You can log in  with the following information:</p><p>Username: [#$user_login#]</p><p>Password: [#$user_password#]</p><br><p>We hope you enjoy. Thanks!</p><p>[#$store_name#]</p>'));


?>