<?php /*?><input type="text" name="address" id="address" value="1600 Amphitheatre Pky, Mountain View, CA" size="50" /><?php */?>
<script type="text/javascript">
function get_address()
{
	var proprty_address=document.getElementById('proprty_address').value;
	var proprty_city=document.getElementById('proprty_city').value;
	var proprty_state=document.getElementById('proprty_state').value;
	var proprty_country=document.getElementById('proprty_country').value;
	var proprty_zip=document.getElementById('proprty_zip').value;
	var address = '';
	if(proprty_address!='')
	{
		address = address+proprty_address;
	}
	if(proprty_city!='')
	{
		if(address)
		{
			address = address+','+proprty_city;	
		}else
		{
			address = address+proprty_city;
		}
	}
	if(proprty_state!='')
	{
		if(address)
		{
			address = address+','+proprty_state;	
		}else
		{
			address = address+proprty_state;
		}
	}
	if(proprty_country!='')
	{
		if(address)
		{
			address = address+','+proprty_country;	
		}else
		{
			address = address+proprty_country;
		}
	}
	if(proprty_zip!='')
	{
		if(address)
		{
			address = address+','+proprty_zip;	
		}else
		{
			address = address+proprty_zip;
		}
	}
	return address;
}
</script>
<input type="button" class="btn_input_normal btn_spacer" value="<?php _e('Set Address on Map');?>" onclick="findAddress(get_address());" />
<div id="map_canvas" style="float:right;
height:300px;
margin-right:36px;
position:relative;
width:410px;"  class="form_row clearfix"></div>