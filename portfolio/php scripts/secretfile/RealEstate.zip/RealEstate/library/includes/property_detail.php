<?php if(have_posts()) : ?>
<?php while(have_posts()) : the_post() ?>
<div class="contentarea">
	
 
	<div class="propertydetails  propertydetails_<?php echo stripslashes(get_option('ptthemes_sidebar_left'));  ?>">
    
    <h1><?php the_title(); ?></h1>	
    
    <div class="propertydetails_toplinks">
		<ul>
       	  <li class="addtofav">
          <!--<a href="#"><?php //_e(ADD_TO_FAVOURITE_TEXT);?></a>-->
          <?php favourite_html($post->post_author,$post->ID); ?>
          </li>
			<li class="sendtofriend"><a href="#" class='sendtofriend' onclick="document.getElementById('frnd_subject').value='<?php echo $post->post_title." (ID: #".$post->ID.")"; ?>';document.getElementById('send_to_Frnd_pid').value='<?php echo $post->ID;?>'"><?php _e(SEND_TO_FRND_TEXT);?></a>
			</li>
		  <li class="print"><a href="#" onclick="window.print();return false;" ><?php _e(PRINT_TEXT);?></a></li>
		</ul>
		<div class="sharelisting">
		
		<?php _e(SHARE_THIS_LISTING_TEXT);?> 
        
        
        <?php if ( get_option('ptthemes_facebook')) { ?>
               <a href="http://www.facebook.com/share.php?u=<?php echo urlencode(the_permalink('','',false)); ?>&amp;t=<?php the_title(); ?>">
        <img src="<?php bloginfo('template_directory'); ?>/images/i-icon-listing01.png" alt="" title="" /></a>
		<?php } ?> 
        
        
         <?php if ( get_option('ptthemes_digg')) {  ?>
           <a href="http://digg.com/submit?phase=2&amp;url=<?php echo urlencode(the_permalink('','',false)); ?>&amp;title=<?php the_title(); ?>&amp;bodytext=<?php the_excerpt(); ?>">
        <img src="<?php bloginfo('template_directory'); ?>/images/i-icon-listing02.png" alt="" title="" /></a>
 		<?php } ?> 
        
        
         <?php if ( get_option('ptthemes_del')) {  ?>
            <a href="http://delicious.com/post?url=<?php echo urlencode(the_permalink('','',false)); ?>&amp;title=<?php the_title(); ?>&amp;notes=<?php the_excerpt(); ?>">
        <img src="<?php bloginfo('template_directory'); ?>/images/i-icon-listing03.png" alt="" title="" /></a>
 		<?php } ?>
        
        <?php if ( get_option('ptthemes_twitter')) {  ?>
            <a href="http://twitter.com/home?status=<?php the_title(); ?> - <?php echo urlencode(the_permalink('','',false)); ?>">
        <img src="<?php bloginfo('template_directory'); ?>/images/i_twitter.png" alt="" title="" /></a>
 		<?php } ?>
        
        
        <?php if ( get_option('ptthemes_reddit')) {  ?>
           <a href="http://reddit.com/submit?url=<?php echo urlencode(the_permalink('','',false)); ?>&amp;title=<?php the_title(); ?>">
        <img src="<?php bloginfo('template_directory'); ?>/images/reddit.gif" alt="" title="" /></a>
 		<?php } ?>
        
         <?php if ( get_option('ptthemes_linkedin')) {  ?>
             <a href="http://www.linkedin.com/shareArticle?mini=true&amp;url=<?php echo urlencode(the_permalink('','',false)); ?>&amp;title=<?php the_title(); ?>&amp;summary=<?php the_excerpt(); ?>">
        <img src="<?php bloginfo('template_directory'); ?>/images/linkedin.png" alt="" title="" /></a>
 		<?php } ?>
        
        
       <?php if ( get_option('ptthemes_technorati')) {  ?>
       <a href="http://technorati.com/faves?add=<?php echo urlencode(the_permalink('','',false)); ?>">
        <img src="<?php bloginfo('template_directory'); ?>/images/technorati.gif" alt="" title="" /></a>
 		<?php } ?>
        
        <?php if ( get_option('ptthemes_myspace')) {  ?>
        <a href="http://www.myspace.com/Modules/PostTo/Pages/?u=<?php echo urlencode(the_permalink('','',false)); ?>&amp;t=<?php the_title(); ?>">
        <img src="<?php bloginfo('template_directory'); ?>/images/myspace.png" alt="" title="" /></a>
 		<?php } ?>
        
       
     </div>
	</div>
    
    
    
	<?php
	
	$large_img_arr = bdw_get_images($post->ID,'medium');
	$thumb_img_arr = bdw_get_images($post->ID,'thumb');
	if(count($large_img_arr)>0)
	{
	?>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/library/js/image-slideshow.js"> </script>
<script> var arrow_over_path='<?php bloginfo('template_directory'); ?>/images/'; </script>
   <div id="dhtmlgoodies_slideshow">
	<div id="previewPane">
		<img src="<?php echo $large_img_arr[0]; ?>"  width="638" height="480" >
		<span id="waitMessage"><?php _e(IMAGE_LOADING_TEXT); ?> </span>	
		<div id="largeImageCaption">1</div>
	</div>
	<?php
	if(count($thumb_img_arr)>1)
	{
		if(count($thumb_img_arr)<=5)
		{
		?>
		<style>#arrow_right,#arrow_left{ display:none;}</style>
		<?php
		}
	?>
	<div id="galleryContainer">
		<div id="arrow_left"><img src="<?php bloginfo('template_directory'); ?>/images/arrow_left.png"></div>
		<div id="arrow_right"><img src="<?php bloginfo('template_directory'); ?>/images/arrow_right.png"></div>
		<div id="theImages">
				<!-- Thumbnails -->
				<?php 
				for($i=0;$i<count($thumb_img_arr);$i++)
				{
				?>
				<a href="#" onclick="showPreview('<?php echo $large_img_arr[$i]; ?>','1');return false"><img src="<?php echo $thumb_img_arr[$i];?>" height="80" width="110"></a>	
				<?php }?>
				<!-- End thumbnails -->
				<div id="slideEnd"></div>
		</div>
	</div>
	<?php }?>
</div>
        
	 
	<?php }?>	
		<div class="basicinfo">
		<?php $cat_info_arr = get_property_cat_id_name($post->ID);?>
			<h2 class="home"><?php _e(BASIC_INFO_TEXT);?> </h2>
			<table width="100%" border="0" cellpadding="0" cellspacing="0">
				<tr>
					<td><?php _e(PRICE_TEXT);?>: <strong><?php echo get_property_price($post->ID);?></strong></td>
					<td><?php _e(ADDRESS_TEXT);?>: <?php echo get_post_meta($post->ID,'address',true);?></td>
				</tr>
				<tr>
					<td><?php _e(TYPE_TEXT);?>: <strong><?php _e(get_post_meta($post->ID,'property_type',true));?></strong></td>
					<td><?php _e(CITY_TEXT);?>: <?php echo get_post_meta($post->ID,'add_city',true);?></td>
				</tr>
				<tr>
					<td><?php _e(BEDS_TEXT);?>: <strong><?php echo get_post_meta($post->ID,'bed_rooms',true);?><?php //echo $cat_info_arr['bed']['name'];//get_post_meta($post->ID,'bed_rooms',true);?></strong></td>
					<td><?php _e(STATE_TEXT);?>: <?php echo get_post_meta($post->ID,'add_state',true);?></td>
				</tr>
				<tr>
					<td><?php _e(BATHS_TEXT);?>: <strong><?php echo get_post_meta($post->ID,'bath_rooms',true);?></strong></td>
					<td><?php _e(COUNTRY_TEXT);?>: <?php echo get_post_meta($post->ID,'add_country',true);?></td>
				</tr>
				<tr>
					<td><?php _e(SQ_FT_TEXT);?>: <strong><?php echo get_post_meta($post->ID,'area',true).' '.get_area_unit();?></strong></td>
					<td><?php _e(ZIP_CODE_TEXT);?>: <?php echo get_post_meta($post->ID,'add_zip_code',true);?></td>
				</tr>
                <tr>
                <td>Times viewed: <b><?php if(function_exists('the_views')) { the_views(); } ?></b></td>
                
                </tr>
			</table>
            
            
            
            
            <h2 class="property_desc"><?php _e('Property Description');?> </h2>
            
			<?php the_content(); ?>
              
		</div>
        
        
        
        
   	  <div class="agent_info clearfix">
      
      
      
            
     <?php
	 $author_info = get_author_info($post->post_author);
	 ?>
    
    <h3> <?php _e(FOR_TEXT); ?> <?php echo get_post_meta($post->ID,'property_type',true);?> <?php _e(BY_AGENT_TEXT); ?></h3>
            	
                <div class="agent_contact">
                 
                <?php 				
				get_user_profile_pic($post->post_author,80,80); ?>
                <p class="agent_name"> <a href="<?php echo get_author_link($echo = false, $post->post_author);?>"><?php echo $author_info->display_name;?></a></p>
                  <p>   <strong><?php _e(LISTING_DETAIL_TEXT); ?> :</strong>  <br  />
                    <?php _e(LISTING_ON_TEXT); ?> : <?php the_time('d/m/Y') ?> <br  />
                    <?php _e(PROPERTY_ID_TEXT); ?> : <?php _e('#'); ?><?php echo $post->ID?> <br  />
                    </p>
                    
                    <h4 class="clearfix"> <?php _e(AGENT_CONTACT_INFO_TEXT); ?> </h4>
                    
                    <ul>
                    	<?php if($author_info->user_url){?>
						<li> <a href="<?php echo $author_info->user_url;?>"> <?php _e(AGENT_WEBSITE_TEXT); ?> </a></li>
						<?php }?>
                        <li> <a href="<?php echo get_author_link($echo = false, $post->post_author);?>"> <?php _e(AGENT_OTHR_LISTING_TEXT); ?></a></li>
						<?php if(get_usermeta( $post->post_author, 'user_phone' )){?>
                        <li> <?php _e(PHONE_TEXT); ?> : <?php echo get_usermeta( $post->post_author, 'user_phone' );?></li>
						<?php }?>
                    </ul>
                    
                </div>
                
                
        <div class="agent_contact_form">
                 		<h4> <?php _e(SCHEDULE_SHOW_TEXT); ?> </h4>
     <script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/library/js/property_detail_validation.js"></script>                   
  <form method="post" name="email_agent" id="property_mail_agent" action="<?php echo get_option('siteurl')."/?page=send_inqury";?>" target="submit_information" >
  <input type="hidden" name="pid" value="<?php echo $post->ID;?>" />
  <input type="hidden" name="aid" value="<?php echo $post->post_author;?>" />  
  <div id="inquiry_send_success_property" class="sucess_msg" style="display:none"></div>                 
<div class="agent_row clearfix">
                        	<label><?php _e(NAME_TEXT); ?> :  <span>*</span></label>
							<input type="text" name="inq_name" value="" id="property_mail_name" class="textfield"   />
                            <span id="span_property_mail_name"></span>
                        </div>
 
                        
<div class="agent_row clearfix">
                        	<label><?php _e(EMAIL_TEXT); ?> :  <span>*</span></label>
							<input type="text" name="inq_email" value="" id="property_mail_email" class="textfield"  />
                            <span id="span_property_mail_email"></span>
                        </div>
                        
<div class="agent_row clearfix">
                        	<label> <?php _e(PHONE_NUMBER_TEXT); ?> : </label>
                            <input name="inq_phone" id="inq_phone" type="text" class="textfield" />
                        </div>
                        
   
                
  <div class="agent_row clearfix">
                   	<label> <?php _e(MESSAGE_TEXT); ?> :  <span>*</span></label>
                   
                  <textarea name="inq_msg" id="property_frnd_comments" cols="" rows="" class="textarea"> </textarea>
                  <span id="span_property_frnd_comments"></span>
  </div>
                        
                  <input name="Send" type="submit"  class="b_agent_contact" value="<?php _e(SEND_BTN_TEXT); ?>" />  
				  <span id="inquiry_send_success"></span>
</form>
                        
          </div>
            
            </div> <!-- agent info #end -->
        
        
		
    <?php if(get_post_meta($post->ID,'add_feature',true)){?>
		<div class="additionalfeatures">
			<h2><?php _e(ADD_FEATURE_TEXT);?></h2>
			<p>
			<?php echo nl2br(stripslashes(get_post_meta($post->ID,'add_feature',true)));?>
			</p>
		</div>
		<?php }?>
        
		
	  <?php
			$add_arr = array();
			if(get_post_meta($post->ID,'address',true))
			{
				$add_arr[] = get_post_meta($post->ID,'address',true);
			}
			if(get_post_meta($post->ID,'add_city',true))
			{
				$add_arr[] = get_post_meta($post->ID,'add_city',true);
			}
			if(get_post_meta($post->ID,'add_state',true))
			{
				$add_arr[] = get_post_meta($post->ID,'add_state',true);
			}
			if(get_post_meta($post->ID,'add_country',true))
			{
				$add_arr[] = get_post_meta($post->ID,'add_country',true);
			}
			if(get_post_meta($post->ID,'add_zip_code',true))
			{
				$add_arr[] = get_post_meta($post->ID,'add_zip_code',true);
			}
			$add_str = '';
			if($add_arr)
			{
				$add_str = implode(',',$add_arr);
			}
			if($add_str)
			{
				$geo_longitude = get_post_meta($post->ID,'geo_longitude',true);
				$geo_latitude = get_post_meta($post->ID,'geo_latitude',true);
			?>
  		<div class="propertymap">
				<h2><?php _e(PROPERYT_MAP_TEXT);?></h2>
				<p><!--<img src="<?php bloginfo('template_directory'); ?>/images/i-propertymap.jpg" width="645" height="358" class="map" />-->
				<?php _e('Location : '); echo $add_str;?>
                 <?php if($geo_longitude &&  $geo_latitude){?>
                <iframe src="<?php echo get_option('siteurl');?>/?page=gmap&pid=<?php echo $post->ID;?>" scrolling="no" frameborder="0" height="358" width="645"></iframe>
                <?php
                }else{?>
                <iframe src="http://maps.google.com/maps?f=q&source=s_q&hl=en&geocode=&q=<?php echo $add_str;?>&ie=UTF8&z=14&iwloc=A&output=embed" height="358" width="645" scrolling="no" frameborder="0" ></iframe>
                <?php }?>
                
				
				</p>
			</div>
			<?php }?>
			<?php echo stripslashes(get_option('ptthemes_single_post_advt'));?>
             <div class="navigation">
			<div class="post_left fl"><?php previous_post_link('%link','&laquo; '.__('Previous Property')) ?></div>
			<div class="post_right fr"><?php next_post_link('%link',__('Next Property').' &raquo;') ?></div>
	</div>
            <?php if(get_option('ptthemes_set_comments')){?>
           <div id="comments">  <?php comments_template(); ?></div>
           <?php }?>
            
		<?php require_once (TEMPLATEPATH . '/library/includes/related_properties.php');?>
        
	</div>
	<div class="sidebar sidebar_<?php echo stripslashes(get_option('ptthemes_sidebar_left'));  ?>">
		  <div class="sidebar_top">
		 		<div class="sidebar_bottom">
					   <?php dynamic_sidebar(7);  ?>
                </div>
	 	</div>
</div>

<?php endwhile; ?>
<?php endif; ?>