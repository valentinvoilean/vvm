<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/library/js/jquery-1.2.6.min.js" ></script>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/library/js/jquery-ui.min.js" ></script>
<script type="text/javascript">
<?php 
$speed = get_option('ptthemes_sliderspeed_homepage');
if($speed<500)
{
	$speed = 1100;
}
if(get_option('ptthemes_homepage_sliderrotate_flag'))
{
	$rotatevar = 'rotate';
}else
{
	$rotatevar = '';
}
?>
	$(document).ready(function(){
		$("#featured > ul").tabs({fx:{opacity: "toggle"}}).tabs("<?php echo $rotatevar;?>", <?php echo $speed;?>, true);
	});
</script>
<?php
$feature_catid = get_cat_id_from_name(get_option('ptthemes_featuredcategory'));
$post_content = get_posts("numberposts=5&category=$feature_catid");
for($i=0;$i<count($post_content);$i++)
{
	$permalink_arr[] = $post_content[$i]->guid;
	$medium_img = bdw_get_images($post_content[$i]->ID,'medium');
	$medium_img_arr[] = $medium_img [0];
	$thumb_img = bdw_get_images($post_content[$i]->ID,'thumb');
	$thumb_img_arr[] = $thumb_img[0];
}
?>
 <div class="featuredproperties">
	<div class="featured_strip"> <?php _e(FEATURED_PROPERTIES_TEXT);?></div>
<div id="featured" >
		  <ul class="ui-tabs-nav">
		  		<?php
				if($thumb_img_arr)
				{
					for($i=0;$i<count($thumb_img_arr);$i++)
					{
					?>
					<li class="ui-tabs-nav-item ui-tabs-selected" id="nav-fragment-1">
					<a href="#fragment-<?php echo $i;?>"><img src="<?php echo $thumb_img_arr[$i]; ?>" alt="" width="90" height="57" /></a>
					</li>
					<?php
					}
				}
				?>
	       </ul>

	    <!-- First Content -->
			<?php
				if($medium_img_arr)
				{
					for($i=0;$i<count($medium_img_arr);$i++)
					{
					?>
					<div id="fragment-<?php echo $i;?>" class="ui-tabs-panel <?php if($i!=0){echo "ui-tabs-hide";}?>" style="">
						<img src="<?php echo $medium_img_arr[$i]; ?>" alt="" width="510" height="342" />
						 <div class="info" >
							<h2><a href="<?php echo $post_content[$i]->guid;?>" ><?php echo $post_content[$i]->post_title;?></a></h2>
							<p><?php if(strlen($post_content[$i]->post_content)>200){echo substr($post_content[$i]->post_content,0,200);}else{ echo $post_content[$i]->post_content; }?>....<a href="<?php echo $post_content[$i]->guid;?>" >read more</a></p>
						 </div>
					</div>
					<?php
					}
				}
				?>
		</div> <!-- featured page -->
    
    
	<div class="featuredagent">
	 	 <?php dynamic_sidebar(2);  ?>
	</div>
</div> <!-- featured properties #end -->