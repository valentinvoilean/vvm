$('#frm_field_<?php echo $field['id'] ?>_container').hide();frmCheckDependent($('#field_<?php echo $observed_field->field_key ?>').val(),<?php echo $observed_field->id ?>);
