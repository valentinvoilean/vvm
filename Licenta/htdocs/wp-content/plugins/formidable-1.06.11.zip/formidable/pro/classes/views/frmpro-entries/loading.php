
<div id="frm_loading" style="display:none;background:url(<?php echo FRM_URL ?>/images/grey_bg.png);">
<div id="frm_loading_content">
<h3><?php _e('Uploading Files. Please Wait.', 'formidable') ?></h3>
<img src="<?php echo includes_url('js/thickbox/loadingAnimation.gif') ?>" alt="" />
</div>
</div>
