<div class="frm_update_msg">
 This plugin version does not give you access to <?php echo $features ?>.<br/>
 <a href="http://formidablepro.com/pricing/" target="_blank">Compare</a> our plans to see about upgrading to Pro. Or enter your account information <a href="<?php echo admin_url('admin.php?page=formidable-settings') ?>">here</a>
 </div>