
<script type="text/javascript">
window.onload=function(){location.href="<?php echo FRM_SCRIPT_URL ?>&frm_action=xml&controller=<?php echo $controller ?>&ids=<?php echo $ids; if(isset($is_template)){ ?>&is_template=<?php echo $is_template; } ?>";} 
</script>